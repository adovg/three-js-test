function test() {
	alert('hello js');
	let sum = (firstNum + secondNum);
	console.console.log(sum);
};



let firstNum = 5,
	secondNum = 10;

test();